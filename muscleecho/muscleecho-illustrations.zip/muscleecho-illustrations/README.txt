MuscleEcho body illustrations
=============================

Anatomical body illustrations used in the iPhone / iPad app MuscleEcho, by Kiyoaki Segawa.
https://kiyonda69.github.io/muscleecho/

Contents
- body/male-000.png ... male-350.png
    Gray muscle figure, transparent background, 900 x 1800 px. The number is the viewing angle in degrees
    around the body: 000 = front, 090 = from the figure's left side, 180 = back.
- regions/male-000-ids.png ... male-350-ids.png
    Region maps for the same views. Red channel = region index x 8 (0 = no region); transparent = outside the body.
- regions.json
    Region index -> region id and the anatomical structures it contains.

How they were made
Rendered in Blender from the Z-Anatomy 3D atlas (muscles and bones, unchanged geometry, gray material,
orthographic camera, 10-degree steps).

License
These illustrations are adapted from Z-Anatomy and are licensed under the
Creative Commons Attribution-ShareAlike 4.0 International License (CC BY-SA 4.0):
https://creativecommons.org/licenses/by-sa/4.0/

Attribution
- "Z-Anatomy - The libre 3D atlas of anatomy" - CC BY-SA 4.0 - https://www.z-anatomy.com
- "BodyParts3D, (C) The Database Center for Life Science" - CC BY-SA 2.1 Japan
  https://dbarchive.biosciencedbc.jp/en/bodyparts3d/
- Illustrations rendered by Kiyoaki Segawa (2026), CC BY-SA 4.0.

If you share these files or something made from them, give the attribution above and share it
under the same license (CC BY-SA 4.0).
