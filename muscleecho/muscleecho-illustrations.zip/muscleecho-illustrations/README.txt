MuscleEcho body illustrations
=============================

The anatomical body illustrations shipped in the iPhone / iPad / Apple Watch app MuscleEcho (version 1.0, 2026),
exactly as used in the app. By Kiyoaki Segawa.
https://kiyonda69.github.io/muscleecho/support/#illustrations

Contents
- body/male-000.heic ... male-359.heic
    Glass-like muscle and bone figure, transparent background, 900 x 1800 px, HEIC.
    The number is the viewing angle in degrees around the body (1-degree steps, 360 views):
    000 = front, 090 = from the figure's left side, 180 = back.
- body-small/male-000-s.heic ... male-359-s.heic
    The same views at 300 x 600 px (shown while the body is spinning).
- regions/male-000-ids.png ... male-359-ids.png
    Region maps for the same views, 900 x 1800 px. Red channel = region index x 8 (0 = no region).
    (The app stores the same maps in a packed binary form.)
- regions.json
    Region index -> region id and the anatomical structures it contains.

How they were made (changes from the source)
Rendered in Blender from the Z-Anatomy 3D atlas: muscles and bones with unchanged geometry, a glass material
(transparency and gloss with a weak emission), orthographic camera turning around the body in 1-degree steps.
In the app, colored overlays are drawn under the glass body from the region maps, and in light mode the
glass image is color-inverted (RGB inverted, transparency kept) and multiplied over a white background.

License
These illustrations are adapted from Z-Anatomy and are licensed under the
Creative Commons Attribution-ShareAlike 4.0 International License (CC BY-SA 4.0):
https://creativecommons.org/licenses/by-sa/4.0/
The App Store terms of use do not limit your rights to these illustrations.

Attribution
- "Z-Anatomy - The libre 3D atlas of anatomy" by Gauthier Kervyn et al. - CC BY-SA 4.0 - https://www.z-anatomy.com
- "BodyParts3D, (C) The Database Center for Life Science" - CC BY-SA 2.1 Japan (the version used by Z-Anatomy);
  BodyParts3D is now licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).
  https://dbarchive.biosciencedbc.jp/en/bodyparts3d/
- Illustrations rendered by Kiyoaki Segawa (2026), CC BY-SA 4.0.

If you share these files or something made from them, give the attribution above and share it
under the same license (CC BY-SA 4.0).
